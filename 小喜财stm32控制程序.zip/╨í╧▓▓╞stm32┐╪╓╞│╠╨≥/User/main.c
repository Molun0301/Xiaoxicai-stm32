#include "stm32f10x.h"
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "Delay.h"
#include "OLED.h"
#include "Servo.h"
#include "Key.h"
#include "serial.h"
#include "gpio_control.h"
#include "action_control.h"


// 定义动作队列和任务句柄
QueueHandle_t xActionQueue = NULL;
TaskHandle_t xSensorTaskHandle = NULL;
TaskHandle_t xSerialTaskHandle = NULL;
TaskHandle_t xActionTaskHandle = NULL;

u8 angle90=90;

// 动作类型枚举（扩展）
typedef enum {
    ACTION_GPIO_CONTROL,
    ACTION_SERVO_SHAKE_HEAD,
    ACTION_SERVO_NOD,
    ACTION_SERVO_MOVE_LEFT_EAR,
    ACTION_SERVO_MOVE_RIGHT_EAR,
    ACTION_MOVE_BOTH_EARS,
    ACTION_THINK,
    ACTION_SAD,
    ACTION_LOWER_HEAD,
    ACTION_IDLE,
    ACTION_RIGHT_HEAD,
    ACTION_LEFT_HEAD,
    ACTION_LOOK_FORWARD,
    ACTION_RANDOM
} ActionCommand;

// 动作命令结构
typedef struct {
    ActionCommand cmd;
    uint8_t data; // 用于传递GPIO等级或其他参数
} ActionMessage;

// 传感器检测任务
void vSensorTask(void *pvParameters) {
    uint8_t lastSensor1State = 1;
//    uint8_t lastSensor2State = 1;
    ActionMessage message;
    while (1) {
        uint8_t currentSensor1State = GPIO_ReadPressureSensor1_Debounced();
//        uint8_t currentSensor2State = GPIO_ReadPressureSensor2_Debounced();

        // 检测传感器1下降沿
        if (lastSensor1State == 1 && currentSensor1State == 0) {
			message.cmd = ACTION_RANDOM;
            xQueueSend(xActionQueue, &message, portMAX_DELAY);
        }
        
        // 检测传感器2下降沿
//        if (lastSensor2State == 1 && currentSensor2State == 0) {
//            xQueueSend(xActionQueue, &message, portMAX_DELAY);
//        }
        
        lastSensor1State = currentSensor1State;
//        lastSensor2State = currentSensor2State;
        
        vTaskDelay(pdMS_TO_TICKS(10)); // 10ms延迟
    }
}

// 串口命令处理任务
void vSerialTask(void *pvParameters) {
    ActionMessage message;
    
    while (1) {
        if (Serial_GetRxFlag()) {
            uint8_t data = Serial_GetRxData();
            
            // 处理GPIO控制命令
            if (data >= '0' && data <= '4') {
                message.cmd = ACTION_GPIO_CONTROL;
                message.data = data;
                xQueueSend(xActionQueue, &message, portMAX_DELAY);
            }
            // 处理动作命令
            else {
                switch(data) {
                    case '5': message.cmd = ACTION_SERVO_SHAKE_HEAD; break;
                    case '6': message.cmd = ACTION_SERVO_NOD; break;
                    case '8': message.cmd = ACTION_SERVO_MOVE_LEFT_EAR; break;
                    case '9': message.cmd = ACTION_SERVO_MOVE_RIGHT_EAR; break;
                    case 'a': message.cmd = ACTION_MOVE_BOTH_EARS; break;
                    case 'b': message.cmd = ACTION_THINK; break;
                    case 'c': message.cmd = ACTION_SAD; break;
                    case 'd': message.cmd = ACTION_LOWER_HEAD; break;
                    case 'e': message.cmd = ACTION_IDLE; break;
                    case 'f': message.cmd = ACTION_RIGHT_HEAD; break;
                    case 'g': message.cmd = ACTION_LEFT_HEAD; break;
                    case 'h': message.cmd = ACTION_LOOK_FORWARD; break;
                    default: break;
                         
                }
                xQueueSend(xActionQueue, &message, portMAX_DELAY);
            }
        }
        vTaskDelay(pdMS_TO_TICKS(5)); // 10ms延迟
    }
}

// 动作执行任务
void vActionTask(void *pvParameters) {
    ActionMessage message;
    
    while (1) {
        if (xQueueReceive(xActionQueue, &message, portMAX_DELAY) == pdPASS) {
            switch(message.cmd) {
                case ACTION_GPIO_CONTROL:
                    GPIO_SetLevel(message.data);
                    break;
                  
                case ACTION_SERVO_SHAKE_HEAD:              
                    Servo_ShakeHead();
                    break;
                    
                case ACTION_SERVO_NOD:
                    Servo_Nod();
                    break;
                    
                case ACTION_SERVO_MOVE_LEFT_EAR:
                    Servo_MoveLeftEar();
                    break;
                    
                case ACTION_SERVO_MOVE_RIGHT_EAR:
                    Servo_MoveRightEar();
                    break;
                    
                case ACTION_MOVE_BOTH_EARS:
                    moveBothEars();
                    break;
                    
                case ACTION_THINK:
                    think();
                    break;
                    
                case ACTION_SAD:
                    Action_Sad();
                    break;
                    
                case ACTION_LOWER_HEAD:
                    Lower_Head();
                    break;
                    
                case ACTION_IDLE:
                    Action_Idle();
                    break;
                    
                case ACTION_RIGHT_HEAD:
                    right_head();
                    break;
                    
                case ACTION_LEFT_HEAD:
                    left_head();
                    break;
                    
                case ACTION_LOOK_FORWARD:
                    reset_position();
                    break;
                    
                case ACTION_RANDOM:
                    Action_Random();
                    break;
            }
        }
    }
}

int main(void) {
    // 硬件初始化
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);  // 设置优先级分组为
	NVIC_SetPriority(USART1_IRQn, 6);        // 设置串口中断优先级
    Serial_Init();
    Servo_Init();
	Servo_SetAngleInit();
    GPIO_Control_Init();
    GPIO_ResetBits(GPIOA, GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7);
    
    // 创建动作队列（最多容纳10个动作）
    xActionQueue = xQueueCreate(20, sizeof(ActionMessage));
    
    // 创建FreeRTOS任务
//    xTaskCreate(vSensorTask, "SensorTask", 512, NULL, 3, &xSensorTaskHandle);
    xTaskCreate(vSerialTask, "SerialTask", 512, NULL, 3, &xSerialTaskHandle);
    xTaskCreate(vActionTask, "ActionTask", 1024, NULL, 3, &xActionTaskHandle); // 最高优先级
    
    // 启动调度器
    vTaskStartScheduler();
    
    // 如果调度器启动失败，进入死循环
    while (1);
}

