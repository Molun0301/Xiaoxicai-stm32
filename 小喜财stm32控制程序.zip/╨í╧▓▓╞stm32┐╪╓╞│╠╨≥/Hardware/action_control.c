/* action_control.c 文件 */
#include "action_control.h"
#include "servo.h"
#include "gpio_control.h"
#include "Delay.h"
#include <stdlib.h>
#include "FreeRTOS.h"
#include "task.h"
#include <stdint.h>
/**
  * @brief  跳舞动作
  */
  
  

 
void Action_Dance(void)
{
    uint8_t i;
        GPIO_SetBits(GPIOA, GPIO_Pin_4 | GPIO_Pin_5);
        GPIO_ResetBits(GPIOA, GPIO_Pin_6 | GPIO_Pin_7);    
    for(i = 0; i < 5; i++) {
        // 左右摇头
        Servo_SetAngle(SERVO_CHANNEL_3, 60);  // 使用SERVO_CHANNEL_1控制水平摇头
        vTaskDelay(pdMS_TO_TICKS(500));
        
        Servo_SetAngle(SERVO_CHANNEL_3, 120);
        vTaskDelay(pdMS_TO_TICKS(500));
        
        // 上下点头
        Servo_SetAngle(SERVO_CHANNEL_3, 60);  // 使用SERVO_CHANNEL_2控制垂直点头
        vTaskDelay(pdMS_TO_TICKS(500));
        
        Servo_SetAngle(SERVO_CHANNEL_3, 120);
        vTaskDelay(pdMS_TO_TICKS(500));
    }
    
    // 恢复默认状态
    Servo_SetAngle(SERVO_CHANNEL_3, 90);
    Servo_SetAngle(SERVO_CHANNEL_3, 90);
    GPIO_ResetBits(GPIOA, GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7);
}

/**
  * @brief  高兴动作
  */
void Action_Happy(void)
{
    uint8_t i;
          GPIO_SetBits(GPIOA, GPIO_Pin_4 | GPIO_Pin_5);
        GPIO_ResetBits(GPIOA, GPIO_Pin_6 | GPIO_Pin_7);  
    for(i = 0; i < 3; i++) {
        // 动右耳
        Servo_SetAngle(SERVO_CHANNEL_3, 60);  // 右耳舵机
        vTaskDelay(pdMS_TO_TICKS(500));
        
        Servo_SetAngle(SERVO_CHANNEL_3, 90);
        vTaskDelay(pdMS_TO_TICKS(500));
        
        // 动左耳
        Servo_SetAngle(SERVO_CHANNEL_3, 120);  // 左耳舵机
        vTaskDelay(pdMS_TO_TICKS(500));
        
        Servo_SetAngle(SERVO_CHANNEL_3, 90);
        vTaskDelay(pdMS_TO_TICKS(500));
    }
    
    // 耳朵一起动
    Servo_SetAngle(SERVO_CHANNEL_3, 60);  // 右耳
    Servo_SetAngle(SERVO_CHANNEL_3, 120); // 左耳
    GPIO_SetBits(GPIOA, GPIO_Pin_4 | GPIO_Pin_6);
    GPIO_ResetBits(GPIOA, GPIO_Pin_5 | GPIO_Pin_7);
    vTaskDelay(pdMS_TO_TICKS(500));
    
    // 恢复默认状态
    Servo_SetAngle(SERVO_CHANNEL_3, 90);
    Servo_SetAngle(SERVO_CHANNEL_3, 90);
    GPIO_ResetBits(GPIOA, GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7);
}

/**
  * @brief  难过动作
  */
void Action_Sad(void)
{
    // 低头
    Servo_SetAngle(SERVO_CHANNEL_2, angle90 - 20);  // 使用SERVO_CHANNEL_2控制低头
	vTaskDelay(1000);
	Servo_SetAngle(SERVO_CHANNEL_1, angle90 - 20);
	vTaskDelay(1000);
	Servo_SetAngle(SERVO_CHANNEL_1, angle90 + 20);
	vTaskDelay(1000);
	Servo_SetAngle(SERVO_CHANNEL_1, angle90);
}

/**
  * @brief  思考动作
  */
void Action_Think(void)
{
    GPIO_SetBits(GPIOA, GPIO_Pin_4 | GPIO_Pin_6);
    GPIO_ResetBits(GPIOA, GPIO_Pin_5 | GPIO_Pin_7);	
    // 左右转头思考
    uint8_t i;
    for(i = 0; i < 4; i++) {
        Servo_SetAngle(SERVO_CHANNEL_3, 60);  // 使用SERVO_CHANNEL_1控制水平转头
        vTaskDelay(pdMS_TO_TICKS(500));
        
        Servo_SetAngle(SERVO_CHANNEL_3, 120);
        vTaskDelay(pdMS_TO_TICKS(500));
    }
    
    // 中间位置停留思考
    Servo_SetAngle(SERVO_CHANNEL_3, 90);
    GPIO_SetBits(GPIOA, GPIO_Pin_4 | GPIO_Pin_6);
    GPIO_ResetBits(GPIOA, GPIO_Pin_5 | GPIO_Pin_7);
    vTaskDelay(pdMS_TO_TICKS(500));
    
    // 恢复默认状态
    GPIO_ResetBits(GPIOA, GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7);
}

/**
  * @brief  发呆动作
  */
void Action_Idle(void)
{
    // 轻微摇头
	
//    GPIO_SetBits(GPIOA, GPIO_Pin_4 | GPIO_Pin_6);
//    GPIO_ResetBits(GPIOA, GPIO_Pin_5 | GPIO_Pin_7);	
	Servo_SetAngle(SERVO_CHANNEL_1, angle90 - 20 );
	Servo_SetAngle(SERVO_CHANNEL_2, angle90 + 20 );
    uint8_t i;
    for(i = 0; i < 2; i++) {
        Servo_SetAngle(SERVO_CHANNEL_3, angle90 - 20);
		Servo_SetAngle(SERVO_CHANNEL_4, angle90 - 20);
        vTaskDelay(pdMS_TO_TICKS(300));
        Servo_SetAngle(SERVO_CHANNEL_3, angle90 + 20);
        Servo_SetAngle(SERVO_CHANNEL_4, angle90 + 20);		
        vTaskDelay(pdMS_TO_TICKS(300));
    }
    
    // 恢复默认状态
    Servo_SetAngle(SERVO_CHANNEL_3, angle90 );
	Servo_SetAngle(SERVO_CHANNEL_4, angle90 );

//    GPIO_ResetBits(GPIOA, GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7);
}


void moveBothEars(void) {
	
	Servo_SetAngle(SERVO_CHANNEL_3, 60);
	Servo_SetAngle(SERVO_CHANNEL_4, 60);
    vTaskDelay(pdMS_TO_TICKS(500));
    Servo_SetAngle(SERVO_CHANNEL_3, 120);
	Servo_SetAngle(SERVO_CHANNEL_4, 120);
    vTaskDelay(pdMS_TO_TICKS(500));
	Servo_SetAngle(SERVO_CHANNEL_3, 90);
	Servo_SetAngle(SERVO_CHANNEL_4, 90);
	
}

void think(void) {
	
	Servo_SetAngle(SERVO_CHANNEL_1, angle90+20);
	Servo_SetAngle(SERVO_CHANNEL_2, angle90+20);
	
	Servo_SetAngle(SERVO_CHANNEL_3, angle90-30);
	Servo_SetAngle(SERVO_CHANNEL_4, angle90-30);
    vTaskDelay(pdMS_TO_TICKS(500));
    Servo_SetAngle(SERVO_CHANNEL_3, angle90+30);
	Servo_SetAngle(SERVO_CHANNEL_4, angle90+30);
    vTaskDelay(pdMS_TO_TICKS(500));
	Servo_SetAngle(SERVO_CHANNEL_3, angle90);
	Servo_SetAngle(SERVO_CHANNEL_4, angle90);
	
}

void Lower_Head(void) {
    Servo_SetAngle(SERVO_CHANNEL_2, angle90-20);
}

void right_head(void) {
    Servo_SetAngle(SERVO_CHANNEL_3, angle90-20);
}

void left_head(void){
    Servo_SetAngle(SERVO_CHANNEL_4, angle90+20);
}

void reset_position(void) {
	Servo_SetAngle (SERVO_CHANNEL_1, angle90 );
	Servo_SetAngle (SERVO_CHANNEL_2, angle90 );
    Servo_SetAngle (SERVO_CHANNEL_3, angle90 );
    Servo_SetAngle (SERVO_CHANNEL_4, angle90 );
}


/**
  * @brief  获取动作名称字符串
  */
//const char* Action_GetName(Action_TypeDef action)
//{
//    static const char* actionNames[] = {
//        "Dance",
//        "Happy",
//        "Sad",
//        "Think",
//        "Idle"
//    };
//    
//    if (action < ACTION_MAX) {
//        return actionNames[action];
//    }
//    
//    return "Unknown";
//	return 0;
//}


/**
  * @brief  生成0到4的随机整数
  * @retval 0-4之间的随机整数
  */
uint8_t GenerateRandom0to4(void) {
    static uint32_t seed = 0xACE1;  // 任意非零初始种子
    
    // 简单的线性反馈移位寄存器(LFSR)算法
    // 使用16位LFSR生成伪随机序列
    uint16_t lfsr = (uint16_t)(seed & 0xFFFF);
    uint8_t bit = ((lfsr >> 0) ^ (lfsr >> 2) ^ (lfsr >> 3) ^ (lfsr >> 5)) & 1;
    lfsr = (lfsr >> 1) | (bit << 15);
    
    // 更新种子
    seed = (seed >> 16) | (lfsr << 16);
    
    // 生成0-4范围内的随机数
    // 使用除法确保均匀分布
    return (lfsr % 5);
}

/**
  * @brief  随机选择一个动作执行并返回动作类型
  */
void Action_Random(void)
{
    u8 action = GenerateRandom0to4();
    
    // 执行对应的动作
    switch(action) {
        case '0':
            Action_Dance();
            break;
        case '1':
            Action_Happy();
            break;
        case '2':
            Action_Sad();
            break;
        case '3':
            Action_Think();
            break;
        case '4':
            Action_Idle();
            break;
        default:
            break;
    }
    
  
}
