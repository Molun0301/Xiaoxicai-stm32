/* servo.h 文件 */
#ifndef __SERVO_H
#define __SERVO_H

#include "stm32f10x.h"
#include "pwm.h"

/**
  * @brief  舵机通道定义
  */
typedef enum {
    SERVO_CHANNEL_1 = PWM_CHANNEL_1,  // PA0 (TIM2_CH1)
    SERVO_CHANNEL_2 = PWM_CHANNEL_2,  // PA1 (TIM2_CH2)
    SERVO_CHANNEL_3 = PWM_CHANNEL_3,  // PB6 (TIM4_CH1)
    SERVO_CHANNEL_4 = PWM_CHANNEL_4   // PA3 (TIM2_CH4)
} Servo_Channel_TypeDef;

/* 函数声明 */
void Servo_Init(void);
void Servo_SetAngle(Servo_Channel_TypeDef channel, uint8_t angle);
void Servo_ShakeHead(void);
void Servo_Nod(void);
void Servo_MoveLeftEar(void);
void Servo_MoveRightEar(void);
void Servo_Sync90(void);
void Servo_SetAngleInit(void);
void Serial_ClearRxFlag(void); 
#endif /* __SERVO_H */

