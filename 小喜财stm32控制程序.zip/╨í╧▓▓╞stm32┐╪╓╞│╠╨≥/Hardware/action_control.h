/* action_control.h 文件 */
#ifndef __ACTION_CONTROL_H
#define __ACTION_CONTROL_H

#include "stm32f10x.h"


extern u8 angle90;

/* 动作类型枚举 */
typedef enum {
    DANCE = '1',
    HAPPY = '2',
    SAD   = '3',
    IDLE  = '4',
    MAX   = '5',
	MOVEBOTHEARS = 'a',
	Think = 'b',
	Swing = 'c',
	Lower_head = 'd',
	Right_head = 'f',
	Left_Head = 'g',
	Look_Forward = 'h',
} Action_TypeDef;

/* 动作函数声明 */
void Action_Dance(void);     // 跳舞
void Action_Happy(void);     // 高兴
void Action_Sad(void);       // 难过
void Action_Think(void);     // 思考
void Action_Idle(void);      // 发呆
void Action_Random(void);    // 随机动作并返回动作类型
const char* Action_GetName(Action_TypeDef action);  // 获取动作名称

void moveBothEars(void);
void think(void);
void Lower_Head(void);
void right_head(void);
void left_head(void);
void reset_position(void);

#endif /* __ACTION_CONTROL_H */

