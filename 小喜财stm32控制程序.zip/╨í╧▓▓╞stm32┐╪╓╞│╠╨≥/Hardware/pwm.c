#include "pwm.h"

void PWM_Init(void)
{
    // 使能定时器和GPIO时钟
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2 | RCC_APB1Periph_TIM4, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB, ENABLE);
    
    // 配置GPIO为复用推挽输出
    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    
    // 配置TIM2通道1,2,4引脚
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_3;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    // 配置TIM4通道1引脚 (PB6)
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    
    // TIM2时基单元配置 - 通道1,2,4
    TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
    TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInitStructure.TIM_Period = 20000 - 1;    // ARR
    TIM_TimeBaseInitStructure.TIM_Prescaler = 72 - 1;     // PSC
    TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;
    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseInitStructure);
    
    // TIM4时基单元配置 - 通道1
    TIM_TimeBaseInitStructure.TIM_Period = 20000 - 1;    // ARR
    TIM_TimeBaseInitStructure.TIM_Prescaler = 72 - 1;     // PSC
    TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;
    TIM_TimeBaseInit(TIM4, &TIM_TimeBaseInitStructure);
    
    // 初始化输出比较单元
    TIM_OCInitTypeDef TIM_OCInitStructure;
    TIM_OCStructInit(&TIM_OCInitStructure);
    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInitStructure.TIM_OCNPolarity = TIM_OCNPolarity_High;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_Pulse = 1500;  // 初始位置90度
    
    // 配置TIM2的通道1,2,4
    TIM_OC1Init(TIM2, &TIM_OCInitStructure);  // PA0
    TIM_OC2Init(TIM2, &TIM_OCInitStructure);  // PA1
    TIM_OC4Init(TIM2, &TIM_OCInitStructure);  // PA3
    
    // 配置TIM4的通道1
    TIM_OC1Init(TIM4, &TIM_OCInitStructure);  // PB6
    
    // 启动定时器
    TIM_Cmd(TIM2, ENABLE);
    TIM_Cmd(TIM4, ENABLE);
}

void PWM_SetCompare(PWM_Channel_TypeDef channel, uint16_t compare)
{
    // 确保比较值在有效范围内
    if (compare > 20000) {
        compare = 20000;
    }
    
    // 根据通道设置对应的比较寄存器
    switch (channel) {
        case PWM_CHANNEL_1:
            TIM_SetCompare1(TIM2, compare);
            break;
        case PWM_CHANNEL_2:
            TIM_SetCompare2(TIM2, compare);
            break;
        case PWM_CHANNEL_3:
            TIM_SetCompare1(TIM4, compare);  // 使用TIM4的通道1
            break;
        case PWM_CHANNEL_4:
            TIM_SetCompare4(TIM2, compare);
            break;
        default:
            break;
    }
}
