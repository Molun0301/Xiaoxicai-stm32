#ifndef __PWM_H
#define __PWM_H

#include "stm32f10x.h"

/* PWM???? */
typedef enum {
    PWM_CHANNEL_1 = 0,  // PA0 (TIM2_CH1)
    PWM_CHANNEL_2,      // PA1 (TIM2_CH2)
    PWM_CHANNEL_3,      // PB6 (TIM4_CH1) ?????PB10
    PWM_CHANNEL_4       // PA3 (TIM2_CH4)
} PWM_Channel_TypeDef;

/* PWM????? */
void PWM_Init(void);

/* ??PWM??? */
void PWM_SetCompare(PWM_Channel_TypeDef channel, uint16_t compare);

#endif /* __PWM_H */

