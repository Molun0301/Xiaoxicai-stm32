/* servo.c 文件 */
#include "servo.h"
#include "Delay.h"
#include "action_control.h"
#include "FreeRTOS.h"
#include "task.h"
/* SG90舵机参数定义 */
#define SERVO_MIN_PULSE_WIDTH 500    // 最小脉冲宽度 (对应0度位置)
#define SERVO_MAX_PULSE_WIDTH 2500   // 最大脉冲宽度 (对应180度位置)
#define SERVO_ANGLE_RANGE 180        // 角度范围

/**
  * @brief  初始化舵机控制
  * @param  无
  * @retval 无
  */
void Servo_Init(void)
{
    // 初始化PWM输出
    PWM_Init();
}

/**
  * @brief  设置舵机角度
  * @param  channel: 舵机通道
  * @param  angle: 目标角度 (0-180度)
  * @retval 无
  */
void Servo_SetAngle(Servo_Channel_TypeDef channel, uint8_t angle)
{
    // 角度范围检查
    if (angle > 180) {
        angle = 180;
    }
    
    // 角度转换为PWM脉冲宽度 (500-2500us)
    uint16_t pulseWidth = SERVO_MIN_PULSE_WIDTH + 
                         ((uint32_t)angle * (SERVO_MAX_PULSE_WIDTH - SERVO_MIN_PULSE_WIDTH)) / SERVO_ANGLE_RANGE;
    
    // 设置PWM比较值，显式类型转换消除警告
    PWM_SetCompare((PWM_Channel_TypeDef)channel, pulseWidth);
}


void Servo_SetAngleInit(void){

	Servo_SetAngle(SERVO_CHANNEL_1, angle90);
	Servo_SetAngle(SERVO_CHANNEL_2, angle90);
	Servo_SetAngle(SERVO_CHANNEL_3, angle90);
	Servo_SetAngle(SERVO_CHANNEL_4, angle90);
	
}


/**
  * @brief  舵机摇头动作 (水平摆动)
  * @param  无
  * @retval 无
  */
void Servo_ShakeHead(void)
{
    uint8_t i;
    
    // 左右摆动3次
    for (i = 0; i < 2; i++)
    {
        Servo_SetAngle(SERVO_CHANNEL_1, 70);     // 向左
        vTaskDelay(pdMS_TO_TICKS(500));
        Servo_SetAngle(SERVO_CHANNEL_1, 110);    // 向右
        vTaskDelay(pdMS_TO_TICKS(500));
    }
    
    // 回到中间位置
    Servo_SetAngle(SERVO_CHANNEL_1, 90);
    vTaskDelay(pdMS_TO_TICKS(500));
}

/**
  * @brief  舵机点头动作 (垂直摆动)
  * @param  无
  * @retval 无
  */
void Servo_Nod(void)
{
    uint8_t i;
    
    // 上下点头3次
    for (i = 0; i < 2; i++)
    {
        Servo_SetAngle(SERVO_CHANNEL_2, 70);     // 向下
        vTaskDelay(pdMS_TO_TICKS(500));
        Servo_SetAngle(SERVO_CHANNEL_2, 110);    // 向上
        vTaskDelay(pdMS_TO_TICKS(500));
    }
    
    // 回到中间位置
    Servo_SetAngle(SERVO_CHANNEL_2, 90);
    vTaskDelay(pdMS_TO_TICKS(500));
}

/**
  * @brief  左耳朵动作
  * @param  无
  * @retval 无
  */
void Servo_MoveLeftEar(void)
{
    // 动一下左耳朵
    Servo_SetAngle(SERVO_CHANNEL_4, 60);
    vTaskDelay(pdMS_TO_TICKS(300));
    Servo_SetAngle(SERVO_CHANNEL_4, 120);
    vTaskDelay(pdMS_TO_TICKS(300));
	Servo_SetAngle(SERVO_CHANNEL_4, 90);
}

/**
  * @brief  右耳朵动作
  * @param  无
  * @retval 无
  */
void Servo_MoveRightEar(void)
{
    // 动一下右耳朵
    Servo_SetAngle(SERVO_CHANNEL_3, 60);
    vTaskDelay(pdMS_TO_TICKS(300));
    Servo_SetAngle(SERVO_CHANNEL_3, 120);
    vTaskDelay(pdMS_TO_TICKS(300));
	Servo_SetAngle(SERVO_CHANNEL_3, 90);
}

/**
  * @brief  同步两个舵机到90度位置
  * @param  无
  * @retval 无
  */
void Servo_Sync90(void)
{
    // 同步PA3(PWM通道4)和PB6(PWM通道3)到90度位置
    Servo_SetAngle(SERVO_CHANNEL_3, 90);
    Servo_SetAngle(SERVO_CHANNEL_4, 90);
    vTaskDelay(pdMS_TO_TICKS(500));
}


