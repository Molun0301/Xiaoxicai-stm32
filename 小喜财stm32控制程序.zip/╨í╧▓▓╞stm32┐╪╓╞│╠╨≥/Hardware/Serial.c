#include "serial.h"
#include <stdarg.h>
#include "FreeRTOS.h"
#include "task.h"

// ���ջ�����
static volatile struct {
    uint8_t buffer[SERIAL_RX_BUFFER_SIZE];
    uint16_t head;
    uint16_t tail;
    volatile uint8_t count;
} rx_buffer = {0};

// ����״̬��־
static volatile struct {
    uint8_t overflow : 1;    // �����������־
    uint8_t frame_error : 1; // ֡�����־
    uint8_t noise_error : 1; // ���������־
} error_flags = {0};

void Serial_Init(void) {
    // ʹ��ʱ��
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    
    // ����GPIO
    GPIO_InitTypeDef GPIO_InitStructure;
    // TX - PA9
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    // RX - PA10
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    // ����USART
    USART_InitTypeDef USART_InitStructure;
    USART_InitStructure.USART_BaudRate = 115200;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
    USART_Init(USART1, &USART_InitStructure);
    
    // �����ж�
    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 5;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
    
    // ʹ�ܽ����жϺʹ����ж�
    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);
    USART_ITConfig(USART1, USART_IT_ERR, ENABLE);
    
    // ʹ��UART
    USART_Cmd(USART1, ENABLE);
    
    // ��ջ�����
    rx_buffer.head = 0;
    rx_buffer.tail = 0;
    rx_buffer.count = 0;
}

void Serial_SendByte(uint8_t Byte) {
    while(USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
    USART_SendData(USART1, Byte);
}

void Serial_SendString(char *String) {
    while(*String) {
        Serial_SendByte(*String++);
    }
}

void Serial_Printf(char *format, ...) {
    char String[100];
    va_list arg;
    va_start(arg, format);
    vsprintf(String, format, arg);
    va_end(arg);
    Serial_SendString(String);
}

uint8_t Serial_GetRxFlag(void) {
    return (rx_buffer.count > 0);
}

uint8_t Serial_GetRxData(void) {
    uint8_t data = 0;
    
    if(rx_buffer.count > 0) {
        data = rx_buffer.buffer[rx_buffer.tail];
        rx_buffer.tail = (rx_buffer.tail + 1) % SERIAL_RX_BUFFER_SIZE;
        __disable_irq();  // ���жϱ���
        rx_buffer.count--;
        __enable_irq();   // ���ж�
    }
    
    return data;
}

uint8_t Serial_Available(void) {
    return rx_buffer.count;
}

void USART1_IRQHandler(void) {
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;

    // �������ж�
    if (USART_GetITStatus(USART1, USART_IT_RXNE) != RESET) {
        uint8_t data = USART_ReceiveData(USART1);

        if (rx_buffer.count < SERIAL_RX_BUFFER_SIZE) {
            rx_buffer.buffer[rx_buffer.head] = data;
            rx_buffer.head = (rx_buffer.head + 1) % SERIAL_RX_BUFFER_SIZE;

            __disable_irq();  // ���жϱ���
            rx_buffer.count++;
            __enable_irq();   // ���жϱ���
        } else {
            error_flags.overflow = 1; // ���û����������־
        }

        USART_ClearITPendingBit(USART1, USART_IT_RXNE);
    }

    // ��������֡������������ȣ�
    if (USART_GetITStatus(USART1, USART_IT_FE) != RESET) {
        error_flags.frame_error = 1;
        USART_ClearITPendingBit(USART1, USART_IT_FE);
    }

    if (USART_GetITStatus(USART1, USART_IT_NE) != RESET) {
        error_flags.noise_error = 1;
        USART_ClearITPendingBit(USART1, USART_IT_NE);
    }

    // ���ڸ������ȼ������л�
    portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}
