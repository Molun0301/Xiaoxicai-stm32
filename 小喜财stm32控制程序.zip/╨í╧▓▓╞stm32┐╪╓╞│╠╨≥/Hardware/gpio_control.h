/* gpio_control.h 文件 */
#ifndef __GPIO_CONTROL_H
#define __GPIO_CONTROL_H
#include "stm32f10x.h"

/* GPIO控制函数声明 */
void GPIO_Control_Init(void);
void GPIO_SetLevel(uint8_t cmd);
uint8_t GPIO_ReadPressureSensor1(void); // 读取PB12
uint8_t GPIO_ReadPressureSensor2(void); // 读取PB13
uint8_t GPIO_ReadPressureSensor1_Debounced(void); // 带消抖读取PB12
uint8_t GPIO_ReadPressureSensor2_Debounced(void); // 带消抖读取PB13

#endif /* __GPIO_CONTROL_H */


