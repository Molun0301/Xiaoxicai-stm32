/* gpio_control.c 文件 */
#include "gpio_control.h"
#include "stm32f10x.h"
#include "Delay.h"
#include "FreeRTOS.h"
#include "task.h"
/* 消抖相关参数定义 */
#define DEBOUNCE_SAMPLES 5      // 采样次数
#define DEBOUNCE_INTERVAL 5     // 采样间隔(ms)

/* 静态变量存储传感器上次稳定状态 */
static uint8_t lastStableState1 = 1;
static uint8_t lastStableState2 = 1;

void GPIO_Control_Init(void)
{
    // 使能GPIOA和GPIOB时钟
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB, ENABLE);
    
    // 配置GPIOA的4-7为推挽输出
    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    // 配置GPIOB的12-13为浮空输入(接压力传感器D0)
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12 | GPIO_Pin_13;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    
    // 默认输出低电平
    GPIO_ResetBits(GPIOA, GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7);
}

void GPIO_SetLevel(uint8_t cmd)
{
    switch(cmd) {
        case '0':
            // PA4-7全部输出低电平
            GPIO_ResetBits(GPIOA, GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7);
            break;
            
        case '1':
            // 前进
            GPIO_SetBits(GPIOA, GPIO_Pin_5 | GPIO_Pin_6);
            GPIO_ResetBits(GPIOA, GPIO_Pin_4 | GPIO_Pin_7);
            break;
            
        case '2':
            // 后退
            GPIO_ResetBits(GPIOA, GPIO_Pin_5 | GPIO_Pin_6);
            GPIO_SetBits(GPIOA, GPIO_Pin_4 | GPIO_Pin_7);
            break;
            
        case '3':
            // 左转
            GPIO_SetBits(GPIOA, GPIO_Pin_4 | GPIO_Pin_6);
            GPIO_ResetBits(GPIOA, GPIO_Pin_5 | GPIO_Pin_7);
            break;
            
        case '4':
            // 右转
            GPIO_ResetBits(GPIOA, GPIO_Pin_4 | GPIO_Pin_6);
            GPIO_SetBits(GPIOA, GPIO_Pin_5 | GPIO_Pin_7);
            break;
            
        default:
            // 默认不做处理
            break;
    }
}

// 读取压力传感器1(PB12)状态
uint8_t GPIO_ReadPressureSensor1(void)
{
    return GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_12);
}

// 读取压力传感器2(PB13)状态
uint8_t GPIO_ReadPressureSensor2(void)
{
    return GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_13);
}

/* 读取压力传感器1(PB12)状态(带消抖) */
uint8_t GPIO_ReadPressureSensor1_Debounced(void)
{
    uint8_t currentState = GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_12);
    uint8_t samples[DEBOUNCE_SAMPLES];
    uint8_t i, sameCount = 0;
    
    // 采样多次
    for(i = 0; i < DEBOUNCE_SAMPLES; i++) {
        samples[i] = GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_12);
        Delay_ms(DEBOUNCE_INTERVAL);
    }
    
    // 检查所有采样值是否相同
    for(i = 0; i < DEBOUNCE_SAMPLES; i++) {
        if(samples[i] == currentState) {
            sameCount++;
        }
    }
    
    // 如果所有采样值相同，认为是稳定状态
    if(sameCount == DEBOUNCE_SAMPLES) {
        lastStableState1 = currentState;
    }
    
    return lastStableState1;
}

/* 读取压力传感器2(PB13)状态(带消抖) */
uint8_t GPIO_ReadPressureSensor2_Debounced(void)
{
    uint8_t currentState = GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_13);
    uint8_t samples[DEBOUNCE_SAMPLES];
    uint8_t i, sameCount = 0;
    
    // 采样多次
    for(i = 0; i < DEBOUNCE_SAMPLES; i++) {
        samples[i] = GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_13);
        Delay_ms(DEBOUNCE_INTERVAL);
    }
    
    // 检查所有采样值是否相同
    for(i = 0; i < DEBOUNCE_SAMPLES; i++) {
        if(samples[i] == currentState) {
            sameCount++;
        }
    }
    
    // 如果所有采样值相同，认为是稳定状态
    if(sameCount == DEBOUNCE_SAMPLES) {
        lastStableState2 = currentState;
    }
    
    return lastStableState2;
}
